###########
# Problem #
###########

"""
Implement the function 'is_balanced' that takes a string containing parentheses as input
and returns True if the parentheses are balanced, and False otherwise.
Use a stack data structure to solve this problem.
"""

def is_balanced(parentheses):
    # Implement your solution here
    pass

# Test the function
print(is_balanced("((()))"))  # Output: True
print(is_balanced("()()()"))  # Output: True
print(is_balanced("((())"))   # Output: False
