-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 29, 2022 at 05:42 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `phpmotorsbackup`
--

-- --------------------------------------------------------

--
-- Table structure for table `carclassification`
--

CREATE TABLE `carclassification` (
  `classificationId` int(11) NOT NULL,
  `classificationName` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `carclassification`
--

INSERT INTO `carclassification` (`classificationId`, `classificationName`) VALUES
(1, 'SUV'),
(2, 'Classic'),
(3, 'Sports'),
(4, 'Trucks'),
(5, 'Used'),
(12, 'Black');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `clientId` int(10) UNSIGNED NOT NULL,
  `clientFirstname` varchar(15) NOT NULL,
  `clientLastname` varchar(25) NOT NULL,
  `clientEmail` varchar(40) NOT NULL,
  `clientPassword` varchar(255) NOT NULL,
  `clientLevel` enum('1','2','3') NOT NULL DEFAULT '1',
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`clientId`, `clientFirstname`, `clientLastname`, `clientEmail`, `clientPassword`, `clientLevel`, `comment`) VALUES
(6, 'Daen', 'Antule', 'daen@mail.com', '$2y$10$IySaG8pbRIOL5VLSq9j2Ye4714d9USq4qZTuoCYWltMvxusvgAqdu', '1', NULL),
(8, 'Albencel', 'Daenielle', 'big.ash@mail.com', '$2y$10$6vL9Z6DTXsMwG5IlRabMCuDLhmpvFtICP8gLrGWK2fkmGX4lOdQYC', '1', NULL),
(9, 'Daddy', 'Awesome', 'daddy@email.com', '$2y$10$Jnjv/BvY5CM5dWigTbY8q.kmc2rV/Hz9AE7a4IgfJCII5HBLk9cMq', '1', NULL),
(10, 'Admin', 'User', 'admin@cse340.net', '$2y$10$a9Zf4R3/ZAb7s9UOI4KL/uvZwcLNKF6rUcZpAXn2B/4v5oqgjyWei', '3', NULL),
(11, 'Trial', 'Try', 'Test@cse340.net', '$2y$10$gpGWHa8Vi7IiDwhy6.pk5emCicw3X6Ef/Up.OVkWIDbb4dNGNnly.', '1', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `imgId` int(10) UNSIGNED NOT NULL,
  `invId` int(10) UNSIGNED NOT NULL,
  `imgName` varchar(100) NOT NULL,
  `imgPath` varchar(150) NOT NULL,
  `imgDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `imgPrimary` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`imgId`, `invId`, `imgName`, `imgPath`, `imgDate`, `imgPrimary`) VALUES
(3, 1, 'wrangler.jpg', '/phpmotors/images/vehicles/wrangler.jpg', '2022-11-26 21:54:43', 1),
(4, 1, 'wrangler-tn.jpg', '/phpmotors/images/vehicles/wrangler-tn.jpg', '2022-11-26 21:54:43', 1),
(5, 2, 'ford-modelt.jpg', '/phpmotors/images/vehicles/ford-modelt.jpg', '2022-11-26 21:55:37', 1),
(6, 2, 'ford-modelt-tn.jpg', '/phpmotors/images/vehicles/ford-modelt-tn.jpg', '2022-11-26 21:55:37', 1),
(7, 3, 'lambo-Adve.jpg', '/phpmotors/images/vehicles/lambo-Adve.jpg', '2022-11-26 21:56:02', 1),
(8, 3, 'lambo-Adve-tn.jpg', '/phpmotors/images/vehicles/lambo-Adve-tn.jpg', '2022-11-26 21:56:02', 1),
(9, 4, 'monster.jpg', '/phpmotors/images/vehicles/monster.jpg', '2022-11-26 21:56:18', 1),
(10, 4, 'monster-tn.jpg', '/phpmotors/images/vehicles/monster-tn.jpg', '2022-11-26 21:56:18', 1),
(11, 5, 'ms.jpg', '/phpmotors/images/vehicles/ms.jpg', '2022-11-26 21:56:39', 1),
(12, 5, 'ms-tn.jpg', '/phpmotors/images/vehicles/ms-tn.jpg', '2022-11-26 21:56:39', 1),
(13, 6, 'bat.jpg', '/phpmotors/images/vehicles/bat.jpg', '2022-11-26 21:57:03', 1),
(14, 6, 'bat-tn.jpg', '/phpmotors/images/vehicles/bat-tn.jpg', '2022-11-26 21:57:03', 1),
(15, 7, 'mm.jpg', '/phpmotors/images/vehicles/mm.jpg', '2022-11-26 21:57:21', 1),
(16, 7, 'mm-tn.jpg', '/phpmotors/images/vehicles/mm-tn.jpg', '2022-11-26 21:57:21', 1),
(17, 8, 'fire-truck.jpg', '/phpmotors/images/vehicles/fire-truck.jpg', '2022-11-26 21:57:34', 1),
(18, 8, 'fire-truck-tn.jpg', '/phpmotors/images/vehicles/fire-truck-tn.jpg', '2022-11-26 21:57:34', 1),
(19, 9, 'crown-vic.jpg', '/phpmotors/images/vehicles/crown-vic.jpg', '2022-11-26 21:57:46', 1),
(20, 9, 'crown-vic-tn.jpg', '/phpmotors/images/vehicles/crown-vic-tn.jpg', '2022-11-26 21:57:46', 1),
(21, 10, 'camaro.jpg', '/phpmotors/images/vehicles/camaro.jpg', '2022-11-26 21:58:14', 1),
(22, 10, 'camaro-tn.jpg', '/phpmotors/images/vehicles/camaro-tn.jpg', '2022-11-26 21:58:14', 1),
(23, 11, 'escalade.jpg', '/phpmotors/images/vehicles/escalade.jpg', '2022-11-26 21:58:29', 1),
(24, 11, 'escalade-tn.jpg', '/phpmotors/images/vehicles/escalade-tn.jpg', '2022-11-26 21:58:29', 1),
(25, 12, 'hummer.jpg', '/phpmotors/images/vehicles/hummer.jpg', '2022-11-26 21:58:47', 1),
(26, 12, 'hummer-tn.jpg', '/phpmotors/images/vehicles/hummer-tn.jpg', '2022-11-26 21:58:47', 1),
(27, 13, 'aerocar.jpg', '/phpmotors/images/vehicles/aerocar.jpg', '2022-11-26 21:59:00', 1),
(28, 13, 'aerocar-tn.jpg', '/phpmotors/images/vehicles/aerocar-tn.jpg', '2022-11-26 21:59:00', 1),
(29, 14, 'fbi.jpg', '/phpmotors/images/vehicles/fbi.jpg', '2022-11-26 21:59:17', 1),
(30, 14, 'fbi-tn.jpg', '/phpmotors/images/vehicles/fbi-tn.jpg', '2022-11-26 21:59:17', 1),
(33, 24, 'koenigseggjesko.jpg', '/phpmotors/images/vehicles/koenigseggjesko.jpg', '2022-11-26 21:59:44', 1),
(34, 24, 'koenigseggjesko-tn.jpg', '/phpmotors/images/vehicles/koenigseggjesko-tn.jpg', '2022-11-26 21:59:44', 1),
(35, 25, 'ssctuatara.jpg', '/phpmotors/images/vehicles/ssctuatara.jpg', '2022-11-26 22:00:06', 1),
(36, 25, 'ssctuatara-tn.jpg', '/phpmotors/images/vehicles/ssctuatara-tn.jpg', '2022-11-26 22:00:06', 1),
(37, 26, 'bugatticss.jpg', '/phpmotors/images/vehicles/bugatticss.jpg', '2022-11-26 22:00:20', 1),
(38, 26, 'bugatticss-tn.jpg', '/phpmotors/images/vehicles/bugatticss-tn.jpg', '2022-11-26 22:00:20', 1),
(39, 27, 'dviper.jpg', '/phpmotors/images/vehicles/dviper.jpg', '2022-11-26 22:00:46', 1),
(40, 27, 'dviper-tn.jpg', '/phpmotors/images/vehicles/dviper-tn.jpg', '2022-11-26 22:00:46', 1),
(41, 28, 'DeLorean.jpg', '/phpmotors/images/vehicles/DeLorean.jpg', '2022-11-26 22:33:22', 1),
(42, 28, 'DeLorean-tn.jpg', '/phpmotors/images/vehicles/DeLorean-tn.jpg', '2022-11-26 22:33:22', 1),
(45, 15, 'no-image.jpg', '/phpmotors/images/vehicles/no-image.jpg', '2022-11-26 22:42:15', 1),
(46, 15, 'no-image-tn.jpg', '/phpmotors/images/vehicles/no-image-tn.jpg', '2022-11-26 22:42:15', 1),
(47, 24, 'koenigseggjesko1.jpg', '/phpmotors/images/vehicles/koenigseggjesko1.jpg', '2022-11-26 22:54:59', 0),
(48, 24, 'koenigseggjesko1-tn.jpg', '/phpmotors/images/vehicles/koenigseggjesko1-tn.jpg', '2022-11-26 22:54:59', 0),
(49, 24, 'koenigseggjesko2.jpg', '/phpmotors/images/vehicles/koenigseggjesko2.jpg', '2022-11-26 22:55:17', 0),
(50, 24, 'koenigseggjesko2-tn.jpg', '/phpmotors/images/vehicles/koenigseggjesko2-tn.jpg', '2022-11-26 22:55:17', 0),
(51, 25, 'ssctuatara1.jpg', '/phpmotors/images/vehicles/ssctuatara1.jpg', '2022-11-26 22:55:46', 0),
(52, 25, 'ssctuatara1-tn.jpg', '/phpmotors/images/vehicles/ssctuatara1-tn.jpg', '2022-11-26 22:55:46', 0),
(53, 25, 'ssctuatara2.jpg', '/phpmotors/images/vehicles/ssctuatara2.jpg', '2022-11-26 22:55:59', 0),
(54, 25, 'ssctuatara2-tn.jpg', '/phpmotors/images/vehicles/ssctuatara2-tn.jpg', '2022-11-26 22:55:59', 0),
(55, 26, 'bugatticss1.jpg', '/phpmotors/images/vehicles/bugatticss1.jpg', '2022-11-26 22:56:25', 0),
(56, 26, 'bugatticss1-tn.jpg', '/phpmotors/images/vehicles/bugatticss1-tn.jpg', '2022-11-26 22:56:25', 0),
(57, 26, 'bugatticss2.jpg', '/phpmotors/images/vehicles/bugatticss2.jpg', '2022-11-26 22:56:41', 0),
(58, 26, 'bugatticss2-tn.jpg', '/phpmotors/images/vehicles/bugatticss2-tn.jpg', '2022-11-26 22:56:41', 0);

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `invId` int(10) UNSIGNED NOT NULL,
  `invMake` varchar(30) NOT NULL,
  `invModel` varchar(30) NOT NULL,
  `invDescription` text NOT NULL,
  `invImage` varchar(50) NOT NULL,
  `invThumbnail` varchar(50) NOT NULL,
  `invPrice` decimal(10,0) NOT NULL,
  `invStock` smallint(6) NOT NULL,
  `invColor` varchar(20) NOT NULL,
  `classificationId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`invId`, `invMake`, `invModel`, `invDescription`, `invImage`, `invThumbnail`, `invPrice`, `invStock`, `invColor`, `classificationId`) VALUES
(1, 'Jeep ', 'Wrangler', 'The Jeep Wrangler is small and compact with enough power to get you where you want to go. It is great for everyday driving as well as off-roading whether that be on the rocks or in the mud!', '/phpmotors/images/vehicles/wrangler.jpg', '/phpmotors/images/vehicles/wrangler-tn.jpg', '28045', 4, 'Orange', 1),
(2, 'Ford', 'Model T', 'The Ford Model T can be a bit tricky to drive. It was the first car to be put into production. You can get it in any color you want if it is black.', '/phpmotors/images/vehicles/ford-modelt.jpg', '/phpmotors/images/vehicles/ford-modelt-tn.jpg', '30000', 2, 'Black', 2),
(3, 'Lamborghini', 'Adventador', 'This V-12 engine packs a punch in this sporty car. Make sure you wear your seatbelt and obey all traffic laws.', '/phpmotors/images/vehicles/lambo-Adve.jpg', '/phpmotors/images/vehicles/lambo-Adve-tn.jpg', '417650', 1, 'Blue', 3),
(4, 'Monster', 'Truck', 'Most trucks are for working, this one is for fun. This beast comes with 60 inch tires giving you the traction needed to jump and roll in the mud.', '/phpmotors/images/vehicles/monster.jpg', '/phpmotors/images/vehicles/monster-tn.jpg', '150000', 3, 'purple', 4),
(5, 'Mechanic', 'Special', 'Not sure where this car came from. However, with a little tender loving care it will run as good a new.', '/phpmotors/images/vehicles/ms.jpg', '/phpmotors/images/vehicles/ms-tn.jpg', '100', 1, 'Rust', 5),
(6, 'Batmobile', 'Custom', 'Ever want to be a superhero? Now you can with the bat mobile. This car allows you to switch to bike mode allowing for easy maneuvering through traffic during rush hour.', '/phpmotors/images/vehicles/bat.jpg', '/phpmotors/images/vehicles/bat-tn.jpg', '65000', 1, 'Black', 3),
(7, 'Mystery', 'Machine', 'Scooby and the gang always found luck in solving their mysteries because of their 4 wheel drive Mystery Machine. This Van will help you do whatever job you are required to with a success rate of 100%.', '/phpmotors/images/vehicles/mm.jpg', '/phpmotors/images/vehicles/mm-tn.jpg', '10000', 12, 'Green', 1),
(8, 'Spartan', 'Fire Truck', 'Emergencies happen often. Be prepared with this Spartan fire truck. Comes complete with 1000 ft. of hose and a 1000-gallon tank.', '/phpmotors/images/vehicles/fire-truck.jpg', '/phpmotors/images/vehicles/fire-truck-tn.jpg', '50000', 1, 'Red', 4),
(9, 'Ford', 'Crown Victoria', 'After the police force updated their fleet these cars are now available to the public! These cars come equipped with the siren which is convenient for college students running late to class.', '/phpmotors/images/vehicles/crown-vic.jpg', '/phpmotors/images/vehicles/crown-vic-tn.jpg', '10000', 5, 'White', 5),
(10, 'Chevy', 'Camaro', 'If you want to look cool this is the car you need! This car has great performance at an affordable price. Own it today!', '/phpmotors/images/vehicles/camaro.jpg', '/phpmotors/images/vehicles/camaro-tn.jpg', '25000', 10, 'Silver', 3),
(11, 'Cadillac', 'Escalade', 'This styling car is great for any occasion from going to the beach to meeting the president. The luxurious inside makes this car a home away from home.', '/phpmotors/images/vehicles/escalade.jpg', '/phpmotors/images/vehicles/escalade-tn.jpg', '75195', 4, 'Black', 1),
(12, 'GM', 'Hummer', 'Do you have 6 kids and like to go off-roading? The Hummer gives you the small interiors with an engine to get you out of any muddy or rocky situation.', '/phpmotors/images/vehicles/hummer.jpg', '/phpmotors/images/vehicles/hummer-tn.jpg', '58800', 5, 'Yellow', 5),
(13, 'Aerocar International', 'Aerocar', 'Are you sick of rush hour traffic? This car converts into an airplane to get you where you are going fast. Only 6 of these were made, get this one while it lasts!', '/phpmotors/images/vehicles/aerocar.jpg', '/phpmotors/images/vehicles/aerocar-tn.jpg', '1000000', 1, 'Red', 2),
(14, 'FBI', 'Surveillance Van', 'Do you like police shows? You will feel right at home driving this van. Comes complete with surveillance equipment for an extra fee of $2,000 a month. ', '/phpmotors/images/vehicles/fbi.jpg', '/phpmotors/images/vehicles/fbi-tn.jpg', '20000', 1, 'Green', 1),
(15, 'Dog ', 'Car', 'Do you like dogs? Well, this car is for you straight from the 90s from Aspen, Colorado we have the original Dog Car complete with fluffy ears.', '/phpmotors/images/vehicles/dog.jpg', '/phpmotors/images/vehicles/dog-tn.jpg', '35000', 1, 'Brown', 2),
(24, 'Koenigsegg', 'Jesko Absolut', 'The Jesko Absolut will be powered by a 1280 bhp (1600 bhp on E85), twin turbo charged V8 engine, featuring the world&#039;s lightest V8 crankshaft that weighs just 12.5 kg. This flat-plane 180-degree crankshaft produces more power with greater efficiency while achieving a high 8500 rpm rev limit.', '/phpmotors/images/vehicles/koenigseggjesko.jpg', '/phpmotors/images/vehicles/koenigseggjesko-tn.jpg', '3000', 1, 'Dark Black', 12),
(25, 'Tuatara', 'SSC', 'The Tuatara runs a twin-turbo V8 producing 1,750bhp when run on E85 or Methanol, or 1,350bhp on 91 octane fuel. It&#039;s housed in a carbon fibre monocoque and matched to a seven-speed gearbox driving the rear wheels.', '/phpmotors/images/vehicles/ssctuatara.jpg', '/phpmotors/images/vehicles/ssctuatara-tn.jpg', '1900', 1, 'Dark Black', 12),
(26, 'Bugatti', 'Chiron SS', 'The Chiron Super Sport 300+ model is arguably the wildest and most extravagant in the range. Equipped with an 8.0-litre 16-cylinder engine rated at 1,577 horsepower, it can reach a top speed of 489 km/h. In fact, Bugatti set a record by becoming the first automaker to top 300 miles per hour.', '/phpmotors/images/vehicles/bugatticss.jpg', '/phpmotors/images/vehicles/bugatticss-tn.jpg', '4300', 1, 'Dark Black', 12),
(27, 'Dodge', 'Viper', 'The Dodge Viper packs a massive 8.4-liter V-10 engine that makes 645 horsepower and 600 pounds-feet of torque. This rear-wheel-drive exotic sports car comes only with a six-speed manual transmission and is offered as a coupe. It competes with the Chevrolet Corvette, Porsche 911 and Nissan GT-R.', '/phpmotors/images/vehicles/dviper.jpg', '/phpmotors/images/vehicles/dviper-tn.jpg', '200', 1, 'Dark Black', 12),
(28, 'DeLorean Motor Company', 'DeLorean', 'DeLorean DMC-12, an innovative sports car, produced from 1981&ndash;83, with gull-wing doors and stainless-steel body panels. It should have been the commercial coup of the century, leading to massive worldwide sales. For this was the car chosen to star in the blockbusting Back to the Future film trilogy (1985&ndash;90).', 'C:\\xampp\\htdocs\\phpmotors\\images\\vehicles\\DeLorean', 'C:\\xampp\\htdocs\\phpmotors\\images\\vehicles\\DeLorean', '1985', 1, 'Grey', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carclassification`
--
ALTER TABLE `carclassification`
  ADD PRIMARY KEY (`classificationId`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`clientId`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`imgId`),
  ADD KEY `invId` (`invId`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`invId`),
  ADD KEY `classificationId` (`classificationId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carclassification`
--
ALTER TABLE `carclassification`
  MODIFY `classificationId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `clientId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `imgId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `invId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `images`
--
ALTER TABLE `images`
  ADD CONSTRAINT `FK_inv_images` FOREIGN KEY (`invId`) REFERENCES `inventory` (`invId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`classificationId`) REFERENCES `carclassification` (`classificationId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
