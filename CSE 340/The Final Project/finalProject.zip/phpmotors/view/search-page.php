<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Motors Vehicle Detail</title>
    <link href="../css/small.css" type="text/css" rel="stylesheet" media="screen">
    <link href="../css/large.css" type="text/css" rel="stylesheet" media="screen">
    <link href="../css/details.css" type="text/css" rel="stylesheet" media="screen">
    <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap" rel="stylesheet">
</head>

<body>
    <div id="wrapper">

    <header>
        <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/common/header.php'; ?>
    </header>

    <nav>
        <?php echo $navList; ?>
    </nav>

    <main>

    <h1>Search&#x1f50e;</h1>
        <?php
        if (isset($_SESSION['message'])) {
            echo $_SESSION['message'];
        }
        ?>
        <form name="searchForm" action="../search/index.php" method="post">
            <div class="formPage">
                <label for="searchTerm">What are you looking for today?</label>
                <input type="text" name="searchTerm" id="searchTerm" <?php if (isset($searchTerm)) {
                                                                            echo "value='$searchTerm'";
                                                                        }  ?>required>
                <input type="submit" value="Search">
                <input type="hidden" name="action" value="search">
            </div>
        </form>

        <?php
        if (isset($countSearch)) {
            echo "<h2>Returned $countSearch results for: $searchTerm</h2>";
        }

        if (isset($searchDisplay)) {
            echo $searchDisplay;
        }
        
        if (isset($pagi)) {
            echo $pagi;
        }
        ?>

    </main>

<?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/common/footer.php'; ?>

