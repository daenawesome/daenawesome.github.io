
<ul>
    <li><a href="/phpmotors/home.php">Home</a></li>
    <li><a href="#">Classic</a></li>
    <li><a href="#">Sports</a></li>
    <li><a href="#">SUV</a></li>
    <li><a href="#">Trucks</a></li>
    <li><a href="#">Used</a></li>
</ul>