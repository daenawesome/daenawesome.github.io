<?php include $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/common/header.php'; ?>

        <h1>Server Error</h1>
        <p>Sorry, our server seems to bve experiencing some technical difficulties. 
            Please check back later.</p>


<?php include $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/common/footer.php'; ?>